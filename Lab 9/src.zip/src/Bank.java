import java.util.ArrayList;
import java.util.Scanner;

public class Bank {

	private static ArrayList<BankAccount> accounts;
	private int maxSize;
	private int numAccounts;
	BankAccount newAccount;
	Scanner input;

	public Bank() {
		this(1000);
	}

	public Bank(int bankSize) {
		numAccounts = 0;
		maxSize = bankSize;
		accounts = new ArrayList<BankAccount>(maxSize);
		input = new Scanner(System.in);
	}

	public boolean addAccount() {

		char option = 'x';
		newAccount = null;

		System.out.println("Enter details for account number " + (accounts.size() + 1));

		do { 
			System.out.println("Enter account type (s for savings, c for checking): ");
			option = input.next().toLowerCase().charAt(0);

			switch (option) {
			case 'c':
				newAccount = new ChequingAccount();
				break;
			case 's':
				newAccount = new SavingsAccount();
				break;
			default:
				System.out.println("Invalid selection. Please try again.");
			}

		} while (option != 'c' && option != 's');

		if (newAccount.addBankAccount()) {
			accounts.add(newAccount);
			numAccounts += 1;
			return true;
		} 

		return false;
	}

	public boolean readFile(Scanner sc) {

		while(sc.hasNextLine()) {

			String s = sc.nextLine();
			String arr[] = s.split(" ");
			String option = arr[0];
			Long accNum;
			String firstName;
			String lastName;
			String phoneNo;
			String email;
			Person accHolder;

			firstName = arr[2];
			lastName = arr[3];
			phoneNo = arr[4];
			email = arr[5];
			Long phno = (long) 0;
			
			if(option.equals("c")) {
				newAccount = new ChequingAccount();
			}
			else if(option.equals("s")) {
				newAccount = new SavingsAccount();

			}
			else {
				System.out.println("Invalid account option");
				//return false;
				continue;
			}

			if (arr[1].length() <= 8) {
				try {
					accNum = Long.parseLong(arr[1]);
					if (Bank.searchAccounts(accNum) != null) {
						accNum = (long) 0;
						System.out.println("Account number already in use. Please try again.");
					}
				} catch (Exception e) {
					accNum = (long) 0;
					System.out.println("Invalid account number. Please try again.");
				}
			}

			if (phoneNo.length() == 7 || phoneNo.length() == 10) {
				try {
					phno = Long.parseLong(phoneNo);
				} catch (Exception e) {
					phno = (long) 0;
					System.out.println("Invalid phone number. Please try again.");
				}
			}

			accHolder = new Person(firstName,lastName,phno,email);

			try {
				newAccount.balance = Double.parseDouble(arr[6]);	
			} catch (Exception e) {
				newAccount.balance = (double) 0;
				System.out.println("Invalid balance number. Please try again. ");
			}

			newAccount.accNumber = Long.parseLong(arr[1]);
			newAccount.accHolder = accHolder;
			boolean accAdded = false;

			if(arr[0].equals("s")) {
				accAdded = newAccount.addBankAccount(Double.parseDouble(arr[7]),Double.parseDouble(arr[8]));
			}
			else if(arr[0].equals("c")) {
				accAdded = newAccount.addBankAccount(Double.parseDouble(arr[7]));
			}
			else {
				//return false;
				continue;
			}

			if(accAdded) {
				accounts.add(newAccount);
				numAccounts += 1;
				//return true;
			}
			//else
			//return false;
		}
		return true;
	}


	public void updateAccount() {

		BankAccount acc = findAccount();
		if (acc == null) {
			System.out.println("Account number requested not found.");
			return;
		}

		System.out.println("Enter an amount:");
		acc.updateBalance(input.nextDouble());
	}

	public String displayAccount() {

		BankAccount acc = findAccount();

		if (acc == null) {
			return "Account number requested not found.";
		}

		return acc.toString();
	}

	public void printAccountDetails() {
		for (BankAccount acc : accounts) {
			System.out.println(acc);
		}
	}

	public void monthlyUpdate() {
		for (BankAccount acc : accounts) {
			acc.monthlyAccountUpdate();
		}
	}

	public BankAccount findAccount() {

		System.out.println("Enter an account number: ");
		while (!input.hasNextLong()) {
			System.out.println("Invalid account number. Please try again:");
			input.next();
		}
		return searchAccounts(input.nextLong());
	}

	public static BankAccount searchAccounts(long accNumToFind) {
		for (BankAccount acc : accounts) {
			if (acc.getAccNumber() == accNumToFind)
				return acc;
		}
		return null;
	}

	public int getNumAccounts() {
		return numAccounts;
	}


}
